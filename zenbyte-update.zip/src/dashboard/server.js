const express = require('express');
const session = require('express-session');
const helmet  = require('helmet');
const rateLimit = require('express-rate-limit');
const http    = require('http');
const crypto  = require('crypto');
const path    = require('path');
const fs      = require('fs');
const { attachChat } = require('./chat');
const { PermissionsBitField } = require('discord.js');

const LOG_TYPES = require('../config/logTypes');
const { normalizeTicketConfig, normalizeTicketForm, normalizeTicketPanel } = require('../utils/tickets');
const ticketsHandler = require('../handlers/tickets');
const { PROTECTIONS, PUNISHMENTS, mergeConfig } = require('../security/protections');
const { CURVES, ANNOUNCE_MODES } = require('../leveling/config');
const { SIGNALS: ALT_SIGNALS, SENSITIVITY_PRESETS, ACTIONS: ALT_ACTIONS } = require('../altdetect/config');
const verificationHandler = require('../handlers/verification');
const greetingsService = require('../greetings/service');
const { PLACEHOLDERS: GREETING_PLACEHOLDERS } = require('../greetings/config');
const reactionRoleService = require('../reactionrole/service');
const { MODES: RR_MODES, parseEmoji: rrParseEmoji } = require('../reactionrole/config');
const pollService = require('../polls/service');
const socialService = require('../social/service');
const { providerMeta } = require('../social/providers');
const applicationService = require('../applications/service');
const {
  QUESTION_TYPES: APP_QUESTION_TYPES, STATUSES: APP_STATUSES, STATUS_META: APP_STATUS_META,
  ROLE_STATUSES: APP_ROLE_STATUSES, BUTTON_STYLES: APP_BUTTON_STYLES, DEFAULT_PANEL: APP_DEFAULT_PANEL
} = require('../applications/config');
const mcService = require('../membercounter/service');
const { COUNTER_TYPES: MC_COUNTER_TYPES } = require('../membercounter/config');
const { getPremiumStore } = require('../premium');
const { upgradeError, UPGRADE_URL } = require('../premium/messages');
const { LIMITS, limitFor } = require('../premium/limits');

// Current live value for each counter type, so the dashboard can show a preview.
function mcPreview(guild) {
  return {
    all:      guild.memberCount,
    boosters: guild.premiumSubscriptionCount || 0,
    channels: guild.channels.cache.size,
    roles:    Math.max(0, guild.roles.cache.size - 1),
    humans:   guild.members.cache.filter(m => !m.user.bot).size,
    bots:     guild.members.cache.filter(m => m.user.bot).size
  };
}
const logger = require('../utils/logger');
const oauthClient = require('./auth');
const { requireAuth, requireOwner, requireGuildAccess, clientIp } = require('./middleware');

function avatarUrl(user) {
  if (user.avatar) return `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=64`;
  return `https://cdn.discordapp.com/embed/avatars/${(BigInt(user.id) >> 22n) % 6n}.png`;
}

// Never fall back to a hardcoded session secret. Use SESSION_SECRET when set,
// otherwise generate one and persist it locally so logins survive restarts.
function resolveSessionSecret() {
  if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
  const file = path.join(__dirname, '..', '..', '.session-secret');
  try {
    if (fs.existsSync(file)) return fs.readFileSync(file, 'utf8').trim();
    const secret = crypto.randomBytes(48).toString('hex');
    fs.writeFileSync(file, secret, { mode: 0o600 });
    logger.warn('No SESSION_SECRET set. Generated one in .session-secret. Set SESSION_SECRET in your .env for production.');
    return secret;
  } catch {
    return crypto.randomBytes(48).toString('hex');
  }
}

// ── Server ────────────────────────────────────────
module.exports = function startDashboard(client) {
  const app  = express();
  const PORT = process.env.DASHBOARD_PORT || 3000;
  const BASE = require('../config').dashboard.url || `http://localhost:${PORT}`;
  const REDIRECT_URI = `${BASE}/auth/discord/callback`;

  const secure = BASE.startsWith('https://');
  if (secure) app.set('trust proxy', 1);

  const sessionMiddleware = session({
    secret: resolveSessionSecret(),
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 86400000, httpOnly: true, sameSite: 'lax', secure }
  });

  // Security headers. CSP is left off because the dashboard relies on inline
  // handlers, inline styles and same-origin socket.io; the other headers still apply.
  app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));

  app.use(express.json({ limit: '1mb' }));
  app.use(express.static(path.join(__dirname, 'public')));
  app.use(sessionMiddleware);

  // ── Public legal pages (no login — must be reachable by Paddle reviewers) ──
  const legalPages = {
    '/terms': 'terms.html',
    '/terms-of-service': 'terms.html',
    '/tos': 'terms.html',
    '/privacy-policy': 'privacy-policy.html',
    '/privacy': 'privacy-policy.html',
    '/refund-policy': 'refund-policy.html',
    '/refunds': 'refund-policy.html'
  };
  for (const [route, file] of Object.entries(legalPages))
    app.get(route, (_req, res) => res.sendFile(path.join(__dirname, 'public', file)));

  // Rate limiting: a tight limit on auth, a looser one on the API.
  app.use('/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 60, standardHeaders: true, legacyHeaders: false }));
  app.use('/api', rateLimit({ windowMs: 60 * 1000, max: 200, standardHeaders: true, legacyHeaders: false }));

  // CSRF defence: state-changing API calls must come from this dashboard's own origin.
  app.use('/api', (req, res, next) => {
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
      const origin = req.get('origin') || req.get('referer') || '';
      if (origin && !origin.startsWith(BASE)) {
        logger.warn(`Blocked cross-origin ${req.method} ${req.originalUrl} from ${origin} ip=${clientIp(req)}`);
        return res.status(403).json({ error: 'Cross-origin request blocked.' });
      }
    }
    next();
  });

  // ── Discord OAuth2 login ──────────────────────
  app.get('/auth/discord', (req, res) => {
    if (!oauthClient.isConfigured()) return res.redirect('/?error=oauth_not_configured');
    const state = crypto.randomBytes(16).toString('hex');
    req.session.oauthState = state;
    res.redirect(oauthClient.getAuthorizeUrl(REDIRECT_URI, state));
  });

  app.get('/auth/discord/callback', async (req, res) => {
    const { code, state } = req.query;
    if (!code || !state || state !== req.session.oauthState) {
      logger.warn(`Blocked OAuth callback (bad state) ip=${clientIp(req)}`);
      return res.redirect('/?error=auth_failed');
    }
    delete req.session.oauthState;

    try {
      const token  = await oauthClient.exchangeCode(code, REDIRECT_URI);
      const user   = await oauthClient.fetchDiscordUser(token.access_token);

      req.session.userId        = user.id;
      req.session.username      = user.global_name || user.username;  // display label used across the app
      req.session.handle        = user.username;                      // the @username handle
      req.session.displayName   = user.global_name || user.username;  // Discord display name
      req.session.avatar        = avatarUrl(user);

      logger.info(`Dashboard login: ${req.session.username} (${user.id}) from ${clientIp(req)}`);
      res.redirect('/');
    } catch (e) {
      logger.error('OAuth callback failed:', e.message);
      res.redirect('/?error=auth_failed');
    }
  });

  app.get('/api/auth', (req, res) => {
    const links = { invite: oauthClient.getBotInviteUrl(), support: require('../config').dashboard.supportInvite };
    if (!req.session?.userId)
      return res.json({ authenticated: false, configured: oauthClient.isConfigured(), links });
    res.json({
      authenticated: true,
      user: { id: req.session.userId, username: req.session.username, avatar: req.session.avatar },
      links
    });
  });

  app.post('/api/logout', (req, res) => {
    if (req.session?.userId) oauthClient.invalidateUser(req.session.userId);
    req.session.destroy(() => res.json({ success: true }));
  });

  // ── Bot status ─────────────────────────────────
  app.get('/api/status', requireAuth, (req, res) => {
    const uptime = client.uptime || 0;
    const h = Math.floor(uptime / 3600000);
    const m = Math.floor((uptime % 3600000) / 60000);
    const s = Math.floor((uptime % 60000) / 1000);
    res.json({
      ready:     client.isReady(),
      tag:       client.user?.tag || 'Not connected',
      avatarUrl: client.user?.displayAvatarURL({ size: 128 }) || null,
      guilds:    client.guilds.cache.size,
      members:   client.guilds.cache.reduce((sum, g) => sum + (g.memberCount || 0), 0),
      commands:  client.commands.size,
      ping:      client.ws.ping >= 0 ? Math.round(client.ws.ping) : null,
      uptime:    `${h}h ${m}m ${s}s`
    });
  });

  // ── Commands (built dynamically from the loaded command modules) ──
  const OWNER_ID = require('../config').ownerId;
  app.get('/api/commands', requireAuth, (req, res) => {
    const permName = bit => {
      for (const [name, value] of Object.entries(PermissionsBitField.Flags)) if (value === bit) return name;
      return String(bit);
    };
    // Owner-only commands are never disclosed to anyone but the owner — not in the
    // listing, not via the toggle UI, not anywhere the dashboard can reach.
    const isOwner = req.session?.userId === OWNER_ID;
    const list = [...client.commands.values()].filter(cmd => isOwner || !cmd.ownerOnly).map(cmd => {
      const json = cmd.data.toJSON();
      return {
        name:          json.name,
        description:   json.description,
        category:      cmd.category || 'General',
        cooldown:      cmd.cooldown || 0,
        ownerOnly:     !!cmd.ownerOnly,
        adminOnly:     !!cmd.adminOnly,
        permissions:   (cmd.permissions || []).map(permName),
        modPermission: cmd.modPermission ? permName(cmd.modPermission) : null,
        options: (json.options || []).map(o => ({
          name: o.name, description: o.description, type: o.type,
          required: !!o.required, autocomplete: !!o.autocomplete, choices: o.choices || null
        }))
      };
    }).sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
    res.json(list);
  });

  // Guard applied to every guild-scoped route (live admin re-check).
  const guildGuard = requireGuildAccess(client);

  // ── Guilds ─────────────────────────────────────
  app.get('/api/guilds', requireAuth, async (req, res) => {
    res.json(await oauthClient.listAccessibleGuilds(client, req.session));
  });

  // ── Premium (per-user; manage which servers use the account's slots) ──
  const premiumStore = getPremiumStore();

  // Effective cap for a gated feature in a guild (free vs premium).
  const guildLimit = (guildId, feature) => limitFor(feature, premiumStore.isGuildPremium(guildId));

  // Decides what to send when a write would exceed a feature cap. `attempted` is
  // the resulting item count. A free guild over the free cap gets the upgrade
  // nudge; a premium guild over the premium hard cap gets a plain "limit reached".
  // Returns { status, body } to send, or null when it's allowed.
  const limitBlock = (guildId, feature, attempted) => {
    const prem = premiumStore.isGuildPremium(guildId);
    const cap = limitFor(feature, prem);
    if (attempted <= cap) return null;
    if (prem) return { status: 400, body: { error: `Limit reached. This server can have at most ${cap} ${LIMITS[feature].label}.`, limitReached: true } };
    return { status: 403, body: upgradeError(feature) };
  };

  function premiumStatus(userId, accessible) {
    const u = premiumStore.getUser(userId);
    const assignedRows = premiumStore.listServers(userId);
    const assigned = assignedRows.map(r => {
      const g = client.guilds.cache.get(r.guild_id);
      return { id: r.guild_id, name: g?.name || r.guild_id, icon: g?.iconURL?.({ size: 128 }) || null, assignedAt: r.assigned_at };
    });
    return {
      active:     premiumStore.isUserActive(u),
      tier:       u?.premium_tier || null,
      source:     u?.premium_source || null,
      lifetime:   !!u?.lifetime,
      expiresAt:  u?.expires_at || null,
      slotsTotal: premiumStore.slotCapacity(u),
      slotsUsed:  assignedRows.length,
      assigned,
      assignable: accessible,
      limits:     LIMITS,
      upgradeUrl: UPGRADE_URL,
      pricing:    require('../premium/tiers').PRICING,
      buyLinks:   premiumBuyLinks()
    };
  }

  // Direct Gumroad product links, built from PREMIUM_URL + each product permalink.
  function premiumBuyLinks() {
    const base = (process.env.PREMIUM_URL || '').replace(/\/+$/, '');
    const buy = pl => (base && pl) ? `${base}/l/${pl}` : null;
    return {
      pro:       buy(process.env.GUMROAD_PERMALINK_PRO),
      max:       buy(process.env.GUMROAD_PERMALINK_MAX),
      lifetime:  buy(process.env.GUMROAD_PERMALINK_LIFETIME),
      extraSlot: buy(process.env.GUMROAD_PERMALINK_EXTRA_SLOT)
    };
  }

  app.get('/api/premium', requireAuth, async (req, res) => {
    const accessible = await oauthClient.listAccessibleGuilds(client, req.session);
    const status = premiumStatus(req.session.userId, accessible);
    status.profile = {
      id:          req.session.userId,
      handle:      req.session.handle || req.session.username,   // @username
      displayName: req.session.displayName || req.session.username, // Discord display name
      avatar:      req.session.avatar
    };
    res.json(status);
  });

  app.post('/api/premium/assign', requireAuth, async (req, res) => {
    const guildId = String(req.body?.guildId || '');
    if (!/^\d{16,20}$/.test(guildId)) return res.status(400).json({ error: 'Invalid server.' });
    // The user must actually administer that server (and the bot must be in it).
    if (!await oauthClient.assertGuildAccess(client, req.session, guildId, { fresh: true }))
      return res.status(403).json({ error: 'You do not have access to that server.' });

    const result = premiumStore.assignServer(req.session.userId, guildId);
    if (result.error) {
      const map = {
        'no-active-premium': [403, 'You do not have active premium.'],
        'guild-taken':       [409, 'That server already has a premium slot assigned.'],
        'no-slots-free':     [400, 'All of your premium slots are in use. Unassign a server first.']
      };
      const [code, msg] = map[result.error] || [400, 'Could not assign premium.'];
      return res.status(code).json({ error: msg });
    }
    const accessible = await oauthClient.listAccessibleGuilds(client, req.session);
    res.json({ success: true, status: premiumStatus(req.session.userId, accessible) });
  });

  app.post('/api/premium/unassign', requireAuth, async (req, res) => {
    const guildId = String(req.body?.guildId || '');
    premiumStore.unassignServer(req.session.userId, guildId);
    const accessible = await oauthClient.listAccessibleGuilds(client, req.session);
    res.json({ success: true, status: premiumStatus(req.session.userId, accessible) });
  });

  app.get('/api/guild/:id', requireAuth, guildGuard, (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: 'Guild not found' });

    const textChannels = guild.channels.cache
      .filter(c => c.type === 0)
      .map(c => ({ id: c.id, name: c.name, category: c.parent?.name || null }))
      .sort((a, b) => (a.category || '').localeCompare(b.category || '') || a.name.localeCompare(b.name));

    const voiceChannels = guild.channels.cache
      .filter(c => c.type === 2)
      .map(c => ({ id: c.id, name: c.name, category: c.parent?.name || null }))
      .sort((a, b) => (a.category || '').localeCompare(b.category || '') || a.name.localeCompare(b.name));

    const categories = guild.channels.cache
      .filter(c => c.type === 4)
      .map(c => ({ id: c.id, name: c.name }))
      .sort((a, b) => a.name.localeCompare(b.name));

    const roles = guild.roles.cache
      .filter(r => r.id !== guild.id)
      .map(r => ({ id: r.id, name: r.name }))
      .sort((a, b) => b.rawPosition - a.rawPosition);

    res.json({
      id: guild.id, name: guild.name, textChannels, voiceChannels, categories, roles,
      premium: premiumStore.isGuildPremium(guild.id),  // lets the UI show limits/badges upfront
      limits:  LIMITS
    });
  });

  // ── Log channels ───────────────────────────────
  app.get('/api/guild/:id/logs', requireAuth, guildGuard, (req, res) => {
    res.json({
      config:   client.logChannels.get(req.params.id) || {},
      logTypes: LOG_TYPES
    });
  });

  app.put('/api/guild/:id/logs', requireAuth, guildGuard, (req, res) => {
    if (!client.guilds.cache.has(req.params.id)) return res.status(404).json({ error: 'Guild not found' });
    const current = client.logChannels.get(req.params.id) || {};
    for (const [key, val] of Object.entries(req.body)) {
      if (!val) delete current[key]; else current[key] = val;
    }
    client.logChannels.set(req.params.id, current);
    client.saveLogChannels();
    res.json({ success: true, config: current });
  });

  // ── Ticket config ──────────────────────────────
  app.get('/api/guild/:id/tickets', requireAuth, guildGuard, (req, res) => {
    res.json(client.tickets.get(req.params.id) || {});
  });

  app.put('/api/guild/:id/tickets', requireAuth, guildGuard, (req, res) => {
    if (!client.guilds.cache.has(req.params.id)) return res.status(404).json({ error: 'Guild not found' });
    const current = client.tickets.get(req.params.id) || {};
    const updated = normalizeTicketConfig({ ...current, ...req.body });
    client.tickets.set(req.params.id, updated);
    client.saveTickets();
    res.json({ success: true, config: updated });
  });

  // ── Ticket forms (named, reusable open-form question sets) ──
  const saveTicketCfg = (guildId, cfg) => {
    const updated = normalizeTicketConfig(cfg);
    client.tickets.set(guildId, updated);
    client.saveTickets();
    return updated;
  };

  app.post('/api/guild/:id/ticket-forms', requireAuth, guildGuard, (req, res) => {
    const cfg = client.tickets.get(req.params.id) || {};
    const forms = Array.isArray(cfg.forms) ? cfg.forms : [];
    const blk = limitBlock(req.params.id, 'ticketForms', forms.length + 1);
    if (blk) return res.status(blk.status).json(blk.body);
    const form = normalizeTicketForm(req.body || {});
    const updated = saveTicketCfg(req.params.id, { ...cfg, forms: [...forms, form] });
    res.json({ success: true, form, config: updated });
  });

  app.put('/api/guild/:id/ticket-forms/:formId', requireAuth, guildGuard, (req, res) => {
    const cfg = client.tickets.get(req.params.id) || {};
    const forms = Array.isArray(cfg.forms) ? [...cfg.forms] : [];
    const idx = forms.findIndex(f => f.id === req.params.formId);
    if (idx === -1) return res.status(404).json({ error: 'Form not found.' });
    forms[idx] = normalizeTicketForm({ ...forms[idx], ...req.body, id: req.params.formId });
    const updated = saveTicketCfg(req.params.id, { ...cfg, forms });
    res.json({ success: true, form: forms[idx], config: updated });
  });

  app.delete('/api/guild/:id/ticket-forms/:formId', requireAuth, guildGuard, (req, res) => {
    const cfg = client.tickets.get(req.params.id) || {};
    const forms = (cfg.forms || []).filter(f => f.id !== req.params.formId);
    if (forms.length === (cfg.forms || []).length) return res.status(404).json({ error: 'Form not found.' });
    // normalizeTicketConfig clears any panel.formId that pointed at the deleted form.
    const updated = saveTicketCfg(req.params.id, { ...cfg, forms });
    res.json({ success: true, config: updated });
  });

  // ── Ticket panels (each chooses which form it shows) ──
  app.post('/api/guild/:id/ticket-panels', requireAuth, guildGuard, async (req, res) => {
    const cfg = client.tickets.get(req.params.id) || {};
    const panels = Array.isArray(cfg.panels) ? cfg.panels : [];
    const blk = limitBlock(req.params.id, 'ticketPanels', panels.length + 1);
    if (blk) return res.status(blk.status).json(blk.body);
    const panel = normalizeTicketPanel(req.body || {});
    let updated = saveTicketCfg(req.params.id, { ...cfg, panels: [...panels, panel] });

    let published = false;
    let stored = updated.panels.find(p => p.id === panel.id);
    if (req.body?.publish && stored.channelId) {
      const result = await ticketsHandler.publishPanel(client, req.params.id, stored);
      if (!result.ok) return res.status(400).json({ error: result.error });
      stored.messageId = result.messageId;
      updated = saveTicketCfg(req.params.id, updated);
      stored = updated.panels.find(p => p.id === panel.id);
      published = true;
    }
    res.json({ success: true, panel: stored, config: updated, published });
  });

  app.put('/api/guild/:id/ticket-panels/:panelId', requireAuth, guildGuard, async (req, res) => {
    const cfg = client.tickets.get(req.params.id) || {};
    const panels = Array.isArray(cfg.panels) ? [...cfg.panels] : [];
    const idx = panels.findIndex(p => p.id === req.params.panelId);
    if (idx === -1) return res.status(404).json({ error: 'Panel not found.' });
    panels[idx] = normalizeTicketPanel({ ...panels[idx], ...req.body, id: req.params.panelId });
    let updated = saveTicketCfg(req.params.id, { ...cfg, panels });
    let stored = updated.panels.find(p => p.id === req.params.panelId);

    // Re-publish when explicitly asked, or to keep an already-posted panel in sync.
    let published = false;
    if ((req.body?.publish || stored.messageId) && stored.channelId) {
      const result = await ticketsHandler.publishPanel(client, req.params.id, stored);
      if (result.ok) {
        stored.messageId = result.messageId;
        updated = saveTicketCfg(req.params.id, updated);
        stored = updated.panels.find(p => p.id === req.params.panelId);
        published = true;
      } else if (req.body?.publish) {
        return res.status(400).json({ error: result.error });
      }
    }
    res.json({ success: true, panel: stored, config: updated, published });
  });

  app.post('/api/guild/:id/ticket-panels/:panelId/publish', requireAuth, guildGuard, async (req, res) => {
    const cfg = client.tickets.get(req.params.id) || {};
    const panels = Array.isArray(cfg.panels) ? [...cfg.panels] : [];
    const idx = panels.findIndex(p => p.id === req.params.panelId);
    if (idx === -1) return res.status(404).json({ error: 'Panel not found.' });
    if (req.body?.channelId) panels[idx] = normalizeTicketPanel({ ...panels[idx], channelId: req.body.channelId });
    let updated = saveTicketCfg(req.params.id, { ...cfg, panels });
    let stored = updated.panels.find(p => p.id === req.params.panelId);
    const result = await ticketsHandler.publishPanel(client, req.params.id, stored);
    if (!result.ok) return res.status(400).json({ error: result.error });
    stored.messageId = result.messageId;
    updated = saveTicketCfg(req.params.id, updated);
    res.json({ success: true, panel: updated.panels.find(p => p.id === req.params.panelId), config: updated });
  });

  app.delete('/api/guild/:id/ticket-panels/:panelId', requireAuth, guildGuard, async (req, res) => {
    const cfg = client.tickets.get(req.params.id) || {};
    const panel = (cfg.panels || []).find(p => p.id === req.params.panelId);
    if (!panel) return res.status(404).json({ error: 'Panel not found.' });
    const updated = saveTicketCfg(req.params.id, { ...cfg, panels: (cfg.panels || []).filter(p => p.id !== req.params.panelId) });
    // Best effort: remove the panel's own message.
    if (panel.channelId && panel.messageId) {
      const guild = client.guilds.cache.get(req.params.id);
      const ch = guild?.channels.cache.get(panel.channelId);
      const msg = ch && await ch.messages.fetch(panel.messageId).catch(() => null);
      if (msg && msg.author?.id === client.user.id) await msg.delete().catch(() => {});
    }
    res.json({ success: true, config: updated });
  });

  app.get('/api/guild/:id/open-tickets', requireAuth, guildGuard, (req, res) => {
    const gTickets = client.openTickets.get(req.params.id);
    if (!gTickets) return res.json([]);
    const guild = client.guilds.cache.get(req.params.id);
    const list = [];
    for (const [channelId, data] of gTickets) {
      const ch = guild?.channels.cache.get(channelId);
      list.push({ channelId, channelName: ch?.name || channelId, ...data });
    }
    res.json(list);
  });

  // ── Anti-Nuke / Security ──────────────────────
  app.get('/api/guild/:id/security', requireAuth, guildGuard, (req, res) => {
    res.json({
      config:      client.store.getSecurityConfig(req.params.id),
      protections: PROTECTIONS.map(p => ({ key: p.key, label: p.label })),
      punishments: PUNISHMENTS
    });
  });

  app.put('/api/guild/:id/security', requireAuth, guildGuard, (req, res) => {
    if (!client.guilds.cache.has(req.params.id)) return res.status(404).json({ error: 'Guild not found' });
    const merged = mergeConfig(req.body || {});
    client.store.security.set(req.params.id, merged);
    client.store.saveSecurity();
    res.json({ success: true, config: merged });
  });

  // ── Verification ──────────────────────────────
  app.get('/api/guild/:id/verification', requireAuth, guildGuard, (req, res) => {
    res.json(client.store.getVerificationConfig(req.params.id));
  });

  app.put('/api/guild/:id/verification', requireAuth, guildGuard, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: 'Guild not found' });
    const b = req.body || {};
    const config = {
      enabled:          !!b.enabled,
      channelId:        b.channelId || null,
      verifiedRoleId:   b.verifiedRoleId || null,
      panelTitle:       b.panelTitle || null,
      panelDescription: b.panelDescription || null,
      minAccountAgeDays: Math.max(0, parseInt(b.minAccountAgeDays, 10) || 0),
      requireAvatar:    !!b.requireAvatar,
      altAction:        ['kick', 'ban', 'block'].includes(b.altAction) ? b.altAction : 'kick'
    };
    client.store.verification.set(req.params.id, config);
    client.store.saveVerification();

    let posted = false;
    if (b.repost && config.channelId) {
      const channel = guild.channels.cache.get(config.channelId);
      if (channel) { await channel.send(verificationHandler.buildPanel(config)).then(() => posted = true).catch(() => {}); }
    }
    res.json({ success: true, config, posted });
  });

  // ── Welcome / leave messages ──────────────────
  app.get('/api/guild/:id/greetings', requireAuth, guildGuard, (req, res) => {
    res.json({ config: client.store.getGreetingsConfig(req.params.id), placeholders: GREETING_PLACEHOLDERS });
  });

  app.put('/api/guild/:id/greetings', requireAuth, guildGuard, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: 'Guild not found' });
    const config = client.store.setGreetingsConfig(req.params.id, req.body || {});

    // Optional preview: send a sample greeting to the configured channel using the
    // bot itself as the stand-in member, so admins can see exactly how it looks.
    let tested = false;
    const which = req.body?.test;
    if ((which === 'welcome' || which === 'leave') && config[which].channelId) {
      const channel = guild.channels.cache.get(config[which].channelId);
      if (channel && typeof channel.send === 'function') {
        const sample = { id: client.user.id, user: client.user, guild };
        const payload = greetingsService.buildPayload(config[which], sample, guild);
        if (payload) await channel.send(payload).then(() => { tested = true; }).catch(() => {});
      }
    }
    res.json({ success: true, config, tested });
  });

  // ── Autoroles (roles given on join) ───────────
  app.get('/api/guild/:id/autorole', requireAuth, guildGuard, (req, res) => {
    res.json({ config: client.autoroles.getConfig(req.params.id) });
  });

  app.put('/api/guild/:id/autorole', requireAuth, guildGuard, (req, res) => {
    if (!client.guilds.cache.has(req.params.id)) return res.status(404).json({ error: 'Guild not found' });
    // Free servers are capped on total autorole roles (people + bots combined).
    const b = req.body || {};
    const total = (Array.isArray(b.roleIds) ? b.roleIds.length : 0) + (Array.isArray(b.botRoleIds) ? b.botRoleIds.length : 0);
    const blk = limitBlock(req.params.id, 'autoroleRoles', total);
    if (blk) return res.status(blk.status).json(blk.body);
    const config = client.autoroles.setConfig(req.params.id, b);
    res.json({ success: true, config });
  });

  // ── Reaction roles ────────────────────────────
  // Turns incoming [{ emoji, roleId }] into validated mapping objects.
  const buildMappings = raw => (Array.isArray(raw) ? raw : [])
    .map(m => {
      const parsed = rrParseEmoji(m?.emoji);
      if (!parsed || !/^\d{16,20}$/.test(m?.roleId || '')) return null;
      return { ...parsed, roleId: m.roleId };
    })
    .filter(Boolean)
    .slice(0, 20);

  app.get('/api/guild/:id/reactionroles', requireAuth, guildGuard, (req, res) => {
    res.json({ menus: client.reactionroles.listMenus(req.params.id), modes: RR_MODES });
  });

  app.post('/api/guild/:id/reactionroles', requireAuth, guildGuard, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: 'Guild not found' });
    const b = req.body || {};
    if (!guild.channels.cache.get(b.channelId)) return res.status(400).json({ error: 'Pick a valid channel.' });

    const panelBlk = limitBlock(guild.id, 'reactionPanels', client.reactionroles.listMenus(guild.id).length + 1);
    if (panelBlk) return res.status(panelBlk.status).json(panelBlk.body);
    const mapBlk = limitBlock(guild.id, 'reactionMappings', buildMappings(b.mappings).length);
    if (mapBlk) return res.status(mapBlk.status).json(mapBlk.body);

    const managed = b.managed !== false;
    if (!managed) {
      if (!/^\d{16,20}$/.test(b.messageId || '')) return res.status(400).json({ error: 'Provide the existing message ID.' });
      const exists = await guild.channels.cache.get(b.channelId).messages.fetch(b.messageId).catch(() => null);
      if (!exists) return res.status(400).json({ error: 'I could not find that message in that channel.' });
    }

    const menu = client.reactionroles.createMenu(guild.id, {
      channelId: b.channelId, messageId: managed ? null : b.messageId, mode: b.mode, managed,
      embed: b.embed, title: b.title, description: b.description, color: b.color,
      mappings: buildMappings(b.mappings)
    });
    const result = await reactionRoleService.syncPanel(client, guild, menu);
    client.reactionroles.save();
    if (result.error) return res.status(400).json({ error: result.error });
    res.json({ success: true, menu });
  });

  app.put('/api/guild/:id/reactionroles/:menuId', requireAuth, guildGuard, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: 'Guild not found' });
    const existing = client.reactionroles.getMenu(guild.id, req.params.menuId);
    if (!existing) return res.status(404).json({ error: 'Panel not found' });
    const b = req.body || {};
    const mapBlk = limitBlock(guild.id, 'reactionMappings', buildMappings(b.mappings).length);
    if (mapBlk) return res.status(mapBlk.status).json(mapBlk.body);

    const menu = client.reactionroles.updateMenu(guild.id, req.params.menuId, {
      mode: b.mode, embed: b.embed, title: b.title, description: b.description, color: b.color,
      mappings: buildMappings(b.mappings)
    });
    const result = await reactionRoleService.syncPanel(client, guild, menu);
    client.reactionroles.save();
    if (result.error) return res.status(400).json({ error: result.error });
    res.json({ success: true, menu });
  });

  app.delete('/api/guild/:id/reactionroles/:menuId', requireAuth, guildGuard, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: 'Guild not found' });
    const menu = client.reactionroles.deleteMenu(guild.id, req.params.menuId);
    if (!menu) return res.status(404).json({ error: 'Panel not found' });
    // Best effort: delete the bot's own panel message.
    if (menu.managed && menu.messageId) {
      const ch = guild.channels.cache.get(menu.channelId);
      const msg = ch && await ch.messages.fetch(menu.messageId).catch(() => null);
      if (msg && msg.author?.id === client.user.id) await msg.delete().catch(() => {});
    }
    res.json({ success: true });
  });

  // ── Auto responses ────────────────────────────
  const autoResponseConfig = require('../autoresponse/config');

  app.get('/api/guild/:id/autoresponses', requireAuth, guildGuard, (req, res) => {
    res.json({
      rules:  client.autoresponses.list(req.params.id),
      meta:   { matchModes: autoResponseConfig.MATCH_MODES, responseTypes: autoResponseConfig.RESPONSE_TYPES }
    });
  });

  app.post('/api/guild/:id/autoresponses', requireAuth, guildGuard, (req, res) => {
    const blk = limitBlock(req.params.id, 'autoResponses', client.autoresponses.list(req.params.id).length + 1);
    if (blk) return res.status(blk.status).json(blk.body);
    const rule = autoResponseConfig.normalizeRule(req.body || {});
    const valid = autoResponseConfig.validateRule(rule);
    if (!valid.ok) return res.status(400).json({ error: valid.error });
    res.json({ success: true, rule: client.autoresponses.create(req.params.id, rule) });
  });

  app.put('/api/guild/:id/autoresponses/:ruleId', requireAuth, guildGuard, (req, res) => {
    const existing = client.autoresponses.get(req.params.id, req.params.ruleId);
    if (!existing) return res.status(404).json({ error: 'Auto response not found.' });
    const merged = autoResponseConfig.normalizeRule({ ...existing, ...req.body, id: existing.id });
    const valid = autoResponseConfig.validateRule(merged);
    if (!valid.ok) return res.status(400).json({ error: valid.error });
    res.json({ success: true, rule: client.autoresponses.update(req.params.id, req.params.ruleId, merged) });
  });

  app.delete('/api/guild/:id/autoresponses/:ruleId', requireAuth, guildGuard, (req, res) => {
    if (!client.autoresponses.delete(req.params.id, req.params.ruleId))
      return res.status(404).json({ error: 'Auto response not found.' });
    res.json({ success: true });
  });

  // ── Moderators (mod users + roles) ────────────
  app.get('/api/guild/:id/moderators', requireAuth, guildGuard, (req, res) => {
    const m = client.store.moderators.get(req.params.id) || { users: [], roles: [] };
    res.json({ users: m.users || [], roles: m.roles || [] });
  });

  app.put('/api/guild/:id/moderators', requireAuth, guildGuard, (req, res) => {
    const idList = v => Array.isArray(v) ? [...new Set(v.filter(x => /^\d{16,20}$/.test(x)))] : [];
    const config = { users: idList(req.body?.users), roles: idList(req.body?.roles) };
    client.store.moderators.set(req.params.id, config);
    client.store.saveModerators();
    res.json({ success: true, config });
  });

  // ── Command toggles (per guild) ───────────────
  app.get('/api/guild/:id/command-toggles', requireAuth, guildGuard, (req, res) => {
    res.json({ disabled: client.store.getDisabledCommands(req.params.id) });
  });

  // A command is togglable only if it exists and is not owner-only (owner commands
  // are global utilities and must stay invisible/untouchable to guild admins).
  const togglable = name => client.commands.has(name) && !client.commands.get(name).ownerOnly;

  app.put('/api/guild/:id/command-toggles', requireAuth, guildGuard, (req, res) => {
    const { name, enabled } = req.body || {};
    if (!name || !togglable(name)) return res.status(400).json({ error: 'Unknown command.' });
    const disabled = client.store.setCommandEnabled(req.params.id, name, !!enabled);
    res.json({ success: true, disabled });
  });

  // Bulk enable/disable (e.g. a whole category, or the current filtered view).
  app.put('/api/guild/:id/command-toggles/bulk', requireAuth, guildGuard, (req, res) => {
    const names = Array.isArray(req.body?.names) ? req.body.names.filter(togglable) : [];
    if (!names.length) return res.status(400).json({ error: 'No valid commands provided.' });
    const disabled = client.store.setCommandsEnabled(req.params.id, names, !!req.body.enabled);
    res.json({ success: true, disabled });
  });

  // ── Per-command channel rules (blacklist / whitelist) ──
  app.get('/api/guild/:id/channel-rules', requireAuth, guildGuard, (req, res) => {
    res.json({ rules: client.store.getChannelRules(req.params.id) });
  });

  app.put('/api/guild/:id/channel-rules', requireAuth, guildGuard, (req, res) => {
    const { name, mode, channels } = req.body || {};
    if (!name || !togglable(name)) return res.status(400).json({ error: 'Unknown command.' });
    if (!['off', 'blacklist', 'whitelist'].includes(mode))
      return res.status(400).json({ error: 'Invalid mode.' });
    const list = Array.isArray(channels) ? channels : [];
    const rule = client.store.setChannelRule(req.params.id, name, mode, list);
    res.json({ success: true, rule });
  });

  // ── General settings (per guild) ──────────────
  app.get('/api/guild/:id/prefix', requireAuth, guildGuard, (req, res) => {
    res.json({ prefix: client.store.getPrefix(req.params.id), defaultPrefix: require('../config').prefix });
  });

  app.put('/api/guild/:id/prefix', requireAuth, guildGuard, (req, res) => {
    const p = typeof req.body?.prefix === 'string' ? req.body.prefix.trim() : '';
    if (/\s/.test(p) || p.length > 5)
      return res.status(400).json({ error: 'Prefix must be 1 to 5 characters with no spaces.' });
    res.json({ success: true, prefix: client.store.setPrefix(req.params.id, p) });
  });

  // ── Leveling ──────────────────────────────────
  app.get('/api/guild/:id/leveling', requireAuth, guildGuard, (req, res) => {
    res.json({
      config: client.levels.getConfig(req.params.id),
      curves: CURVES,
      announceModes: ANNOUNCE_MODES
    });
  });

  app.put('/api/guild/:id/leveling', requireAuth, guildGuard, (req, res) => {
    const rewards = Array.isArray(req.body?.roleRewards) ? req.body.roleRewards : null;
    if (rewards) {
      const blk = limitBlock(req.params.id, 'levelingRewards', rewards.length);
      if (blk) return res.status(blk.status).json(blk.body);
    }
    const config = client.levels.setConfig(req.params.id, req.body || {});
    res.json({ success: true, config });
  });

  // ── Activity ──────────────────────────────────
  app.get('/api/guild/:id/activity', requireAuth, guildGuard, (req, res) => {
    res.json({ config: client.activity.getConfig(req.params.id) });
  });

  app.put('/api/guild/:id/activity', requireAuth, guildGuard, (req, res) => {
    const config = client.activity.setConfig(req.params.id, req.body || {});
    res.json({ success: true, config });
  });

  // ── Trust ─────────────────────────────────────
  app.get('/api/guild/:id/trust', requireAuth, guildGuard, (req, res) => {
    res.json({ config: client.trust.getConfig(req.params.id) });
  });

  app.put('/api/guild/:id/trust', requireAuth, guildGuard, (req, res) => {
    res.json({ success: true, config: client.trust.setConfig(req.params.id, req.body || {}) });
  });

  // ── Alt Detection ─────────────────────────────
  app.get('/api/guild/:id/altdetect', requireAuth, guildGuard, (req, res) => {
    res.json({
      config:   client.altdetect.getConfig(req.params.id),
      signals:  ALT_SIGNALS,
      presets:  SENSITIVITY_PRESETS,
      actions:  ALT_ACTIONS,
      flags:    client.altdetect.listFlags(req.params.id).slice(0, 50),
      pending:  client.altdetect.pendingCount(req.params.id)
    });
  });

  app.put('/api/guild/:id/altdetect', requireAuth, guildGuard, (req, res) => {
    if (!client.guilds.cache.has(req.params.id)) return res.status(404).json({ error: 'Guild not found' });
    const config = client.altdetect.setConfig(req.params.id, req.body || {});
    res.json({ success: true, config });
  });

  app.post('/api/guild/:id/altdetect/flags/:userId', requireAuth, guildGuard, (req, res) => {
    const status = ['cleared', 'actioned', 'pending'].includes(req.body?.status) ? req.body.status : 'cleared';
    const flag = client.altdetect.setFlagStatus(req.params.id, req.params.userId, status, req.session.userId);
    if (!flag) return res.status(404).json({ error: 'Flag not found' });
    res.json({ success: true, flag });
  });

  // ── Polls ─────────────────────────────────────
  const pollSummary = p => {
    const a = pollService.analytics(p);
    return {
      id: p.id, question: p.question, status: p.status, channelId: p.channelId,
      multi: p.multi, maxChoices: p.maxChoices, anonymous: p.anonymous, hideResults: p.hideResults,
      createdBy: p.createdBy, createdAt: p.createdAt, endsAt: p.endsAt, scheduledFor: p.scheduledFor,
      voters: a.voters, totalVotes: a.totalVotes, options: a.options
    };
  };

  app.get('/api/guild/:id/polls', requireAuth, guildGuard, (req, res) => {
    res.json({
      config: client.polls.getConfig(req.params.id),
      polls:  client.polls.listPolls(req.params.id).map(pollSummary)
    });
  });

  app.put('/api/guild/:id/polls/config', requireAuth, guildGuard, (req, res) => {
    res.json({ success: true, config: client.polls.setConfig(req.params.id, req.body || {}) });
  });

  app.post('/api/guild/:id/polls', requireAuth, guildGuard, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: 'Guild not found' });
    const b = req.body || {};
    const channel = guild.channels.cache.get(b.channelId);
    if (!channel || channel.type !== 0) return res.status(400).json({ error: 'Pick a valid text channel.' });

    const options = Array.isArray(b.options) ? b.options.map(s => String(s).trim()).filter(Boolean) : [];
    if (!b.question || options.length < 2) return res.status(400).json({ error: 'A poll needs a question and at least two options.' });
    const config = client.polls.getConfig(guild.id);
    // Tier ceiling first (free over free limit -> upgrade nudge, premium over its
    // ceiling -> plain limit-reached), then the admin's soft cap within that.
    const pollBlk = limitBlock(guild.id, 'pollOptions', options.length);
    if (pollBlk) return res.status(pollBlk.status).json(pollBlk.body);
    const effectiveMax = pollService.effectiveMaxOptions(config, premiumStore.isGuildPremium(guild.id));
    if (options.length > effectiveMax) return res.status(400).json({ error: `At most ${effectiveMax} options per poll.` });

    try {
      const poll = await pollService.createPoll(client, {
        guild, channel, creator: { id: req.session.userId },
        question: String(b.question).slice(0, 256), options,
        multi: !!b.multi, maxChoices: parseInt(b.maxChoices, 10) || options.length,
        anonymous: !!b.anonymous, hideResults: !!b.hideResults,
        allowedRoleIds: Array.isArray(b.allowedRoleIds) ? b.allowedRoleIds : [],
        durationMs: Math.max(0, parseInt(b.durationMin, 10) || 0) * 60000,
        scheduleMs: Math.max(0, parseInt(b.scheduleMin, 10) || 0) * 60000
      });
      res.json({ success: true, poll: pollSummary(poll) });
    } catch (e) {
      logger.error('Dashboard poll create failed:', e.message);
      res.status(500).json({ error: 'Could not post the poll. Check that I can send messages in that channel.' });
    }
  });

  app.post('/api/guild/:id/polls/:pollId/:op', requireAuth, guildGuard, async (req, res) => {
    const poll = client.polls.getPoll(req.params.id, req.params.pollId);
    if (!poll) return res.status(404).json({ error: 'Poll not found' });
    const by = req.session.username || 'dashboard';
    if (req.params.op === 'end') await pollService.endPoll(client, poll, by);
    else if (req.params.op === 'cancel') await pollService.cancelPoll(client, poll);
    else return res.status(400).json({ error: 'Unknown action' });
    res.json({ success: true, poll: pollSummary(poll) });
  });

  // ── Social media notifications ────────────────
  app.get('/api/guild/:id/social', requireAuth, guildGuard, (req, res) => {
    res.json({ config: client.social.getConfig(req.params.id), providers: providerMeta() });
  });

  app.put('/api/guild/:id/social', requireAuth, guildGuard, (req, res) => {
    const current = client.social.getConfig(req.params.id);
    const incoming = req.body?.platforms || {};
    for (const pid of Object.keys(current.platforms)) {
      const s = incoming[pid];
      if (!s) continue;
      const pc = current.platforms[pid];
      pc.enabled = !!s.enabled;
      pc.channelId = s.channelId || null;
      pc.mentionRoleId = s.mentionRoleId || null;
      if (typeof s.template === 'string') pc.template = s.template;
    }
    res.json({ success: true, config: client.social.setConfig(req.params.id, current) });
  });

  app.post('/api/guild/:id/social/creator', requireAuth, guildGuard, async (req, res) => {
    const { platform, account } = req.body || {};
    const cfg = client.social.getConfig(req.params.id);
    const total = Object.values(cfg.platforms).reduce((n, p) => n + (p.creators?.length || 0), 0);
    const blk = limitBlock(req.params.id, 'socialCreators', total + 1);
    if (blk) return res.status(blk.status).json(blk.body);
    const result = await socialService.addCreator(client, req.params.id, platform, account);
    if (result.error) return res.status(400).json({ error: result.error });
    res.json({ success: true, config: client.social.getConfig(req.params.id) });
  });

  app.post('/api/guild/:id/social/creator/delete', requireAuth, guildGuard, (req, res) => {
    const { platform, key } = req.body || {};
    socialService.removeCreator(client, req.params.id, platform, key);
    res.json({ success: true, config: client.social.getConfig(req.params.id) });
  });

  app.post('/api/guild/:id/social/test', requireAuth, guildGuard, async (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: 'Guild not found' });
    const result = await socialService.sendTest(client, guild, req.body?.platform);
    if (result.error) return res.status(400).json({ error: result.error });
    res.json({ success: true });
  });

  // ── Transcripts ───────────────────────────────
  app.get('/api/guild/:id/transcripts', requireAuth, guildGuard, (req, res) => {
    const dir = path.join(__dirname, '..', '..', 'transcripts');
    if (!fs.existsSync(dir)) return res.json([]);
    try {
      const list = fs.readdirSync(dir)
        .filter(f => f.startsWith(req.params.id + '-') && f.endsWith('.json'))
        .map(filename => {
          try {
            const d = JSON.parse(fs.readFileSync(path.join(dir, filename), 'utf8'));
            return {
              filename,
              number:       d.number,
              channelName:  d.channelName,
              type:         d.type,
              priority:     d.priority,
              closedAt:     d.closedAt,
              closedBy:     d.closedBy,
              messageCount: d.messages?.length || 0
            };
          } catch { return null; }
        })
        .filter(Boolean)
        .sort((a, b) => (b.closedAt || 0) - (a.closedAt || 0));
      res.json(list);
    } catch { res.json([]); }
  });

  app.get('/api/transcript/:filename', requireAuth, async (req, res) => {
    const filename = path.basename(req.params.filename);
    if (!filename.endsWith('.json')) return res.status(400).json({ error: 'Invalid file' });

    // Transcripts are named "<guildId>-...json", so verify access to that guild.
    const guildId = filename.split('-')[0];
    if (!await oauthClient.assertGuildAccess(client, req.session, guildId)) {
      logger.warn(`Blocked transcript access: user=${req.session.userId} file=${filename} ip=${clientIp(req)}`);
      return res.status(403).json({ error: 'You do not have access to this transcript.' });
    }

    const file = path.join(__dirname, '..', '..', 'transcripts', filename);
    if (!fs.existsSync(file)) return res.status(404).json({ error: 'Not found' });
    try { res.json(JSON.parse(fs.readFileSync(file, 'utf8'))); }
    catch { res.status(500).json({ error: 'Failed to read transcript' }); }
  });

  // ── Integrations: live Twitch credential check ──
  // Owner only: it performs a network round-trip to Twitch and reports whether the
  // configured Client ID / Secret actually authenticate, so the owner can confirm
  // setup without guessing. Presence is also surfaced per-provider via /social.
  app.get('/api/integrations/twitch', requireAuth, requireOwner, async (_req, res) => {
    const twitch = require('../social/providers/twitch');
    const result = await twitch.validate().catch(e => ({ ok: false, error: e.message }));
    res.json({ configured: twitch.isConfigured(), ...result });
  });

  // ── Bot log files (owner only, may contain sensitive system info) ──
  app.get('/api/logs/:file', requireAuth, requireOwner, (req, res) => {
    const allowed = { bot: 'combined.log', error: 'error.log', out: 'out.log' };
    const filename = allowed[req.params.file];
    if (!filename) return res.status(400).json({ error: 'Invalid log file' });
    const logFile = path.join(__dirname, '..', '..', 'logs', filename);
    if (!fs.existsSync(logFile)) return res.json({ lines: [] });
    try {
      const lines = fs.readFileSync(logFile, 'utf8').trim().split('\n').slice(-300).reverse();
      res.json({ lines });
    } catch { res.json({ lines: [] }); }
  });

  // ── Applications ──────────────────────────────
  // Forms ─ list/create/reorder/update/duplicate/delete
  app.get('/api/guild/:id/applications/forms', requireAuth, guildGuard, (req, res) => {
    res.json({
      forms:  client.applications.listForms(req.params.id),
      config: client.applications.getConfig(req.params.id),
      meta:   {
        questionTypes: APP_QUESTION_TYPES, statuses: APP_STATUSES, statusMeta: APP_STATUS_META,
        roleStatuses: APP_ROLE_STATUSES, buttonStyles: APP_BUTTON_STYLES, panelDefaults: APP_DEFAULT_PANEL
      }
    });
  });

  app.post('/api/guild/:id/applications/forms', requireAuth, guildGuard, (req, res) => {
    const formBlk = limitBlock(req.params.id, 'applicationForms', client.applications.listForms(req.params.id).length + 1);
    if (formBlk) return res.status(formBlk.status).json(formBlk.body);
    if (Array.isArray(req.body?.questions)) {
      const qBlk = limitBlock(req.params.id, 'applicationQuestions', req.body.questions.length);
      if (qBlk) return res.status(qBlk.status).json(qBlk.body);
    }
    const form = client.applications.createForm(req.params.id, req.body || {});
    res.json({ success: true, form });
  });

  app.put('/api/guild/:id/applications/forms-order', requireAuth, guildGuard, (req, res) => {
    const order = Array.isArray(req.body?.order) ? req.body.order.filter(x => typeof x === 'string') : [];
    res.json({ success: true, forms: client.applications.reorderForms(req.params.id, order) });
  });

  app.post('/api/guild/:id/applications/forms/:formId/duplicate', requireAuth, guildGuard, (req, res) => {
    const dupBlk = limitBlock(req.params.id, 'applicationForms', client.applications.listForms(req.params.id).length + 1);
    if (dupBlk) return res.status(dupBlk.status).json(dupBlk.body);
    const form = client.applications.duplicateForm(req.params.id, req.params.formId);
    if (!form) return res.status(404).json({ error: 'Form not found' });
    res.json({ success: true, form });
  });

  app.put('/api/guild/:id/applications/forms/:formId', requireAuth, guildGuard, (req, res) => {
    if (Array.isArray(req.body?.questions)) {
      const qBlk = limitBlock(req.params.id, 'applicationQuestions', req.body.questions.length);
      if (qBlk) return res.status(qBlk.status).json(qBlk.body);
    }
    const form = client.applications.updateForm(req.params.id, req.params.formId, req.body || {});
    if (!form) return res.status(404).json({ error: 'Form not found' });
    res.json({ success: true, form });
  });

  app.delete('/api/guild/:id/applications/forms/:formId', requireAuth, guildGuard, (req, res) => {
    if (!client.applications.deleteForm(req.params.id, req.params.formId))
      return res.status(404).json({ error: 'Form not found' });
    res.json({ success: true });
  });

  // Config
  app.put('/api/guild/:id/applications/config', requireAuth, guildGuard, (req, res) => {
    res.json({ success: true, config: client.applications.setConfig(req.params.id, req.body || {}) });
  });

  // Post / refresh the live applications panel in a channel.
  app.post('/api/guild/:id/applications/panel', requireAuth, guildGuard, async (req, res) => {
    const channelId = typeof req.body?.channelId === 'string' ? req.body.channelId : null;
    const result = await applicationService.publishPanel(client, req.params.id, channelId);
    if (!result.ok) return res.status(400).json({ error: result.error });
    res.json({ success: true, channelId: result.channelId, config: client.applications.getConfig(req.params.id) });
  });

  // Export (must be declared before the :appId routes)
  app.get('/api/guild/:id/applications/export', requireAuth, guildGuard, (req, res) => {
    const apps = client.applications.listApplications(req.params.id, {
      status: req.query.status, formId: req.query.formId, search: req.query.search, limit: 200
    });
    if (req.query.format === 'json') {
      res.setHeader('Content-Disposition', `attachment; filename="applications-${req.params.id}.json"`);
      return res.json(apps.map(a => ({ ...a, actions: undefined })));
    }
    const csvCell = v => {
      const s = String(v ?? '');
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const rows = [['id', 'form', 'user_tag', 'user_id', 'status', 'created_at', 'answers']];
    for (const a of apps) {
      const answers = (a.answers || []).map(x => `${x.label}: ${x.value}`).join(' | ');
      rows.push([a.id, a.formName, a.userTag, a.userId, a.status, new Date(a.createdAt).toISOString(), answers]);
    }
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="applications-${req.params.id}.csv"`);
    res.send(rows.map(r => r.map(csvCell).join(',')).join('\n'));
  });

  // Applications ─ list (with filters) + counts
  app.get('/api/guild/:id/applications', requireAuth, guildGuard, (req, res) => {
    res.json({
      applications: client.applications.listApplications(req.params.id, {
        status: req.query.status, formId: req.query.formId, search: req.query.search,
        limit: req.query.limit, offset: req.query.offset
      }),
      counts: client.applications.countByStatus(req.params.id)
    });
  });

  // Perform a review action from the dashboard.
  app.post('/api/guild/:id/applications/:appId/action', requireAuth, guildGuard, async (req, res) => {
    const action = req.body?.action;
    if (!(action in applicationService.ACTION_STATUS))
      return res.status(400).json({ error: 'Unknown action.' });
    const note = typeof req.body?.note === 'string' ? req.body.note.slice(0, 1500) : null;
    if ((action === 'deny' || action === 'info') && !note?.trim())
      return res.status(400).json({ error: 'A message is required for this action.' });

    const updated = await applicationService.applyDecision(client, {
      guildId: req.params.id, appId: req.params.appId, action, note,
      reviewer: { id: req.session.userId, tag: req.session.username || 'Dashboard' }
    });
    if (!updated) return res.status(404).json({ error: 'Application not found' });
    res.json({ success: true, application: updated });
  });

  app.get('/api/guild/:id/applications/:appId', requireAuth, guildGuard, (req, res) => {
    const app2 = client.applications.getApplication(req.params.id, req.params.appId);
    if (!app2) return res.status(404).json({ error: 'Application not found' });
    res.json(app2);
  });

  // ── Member Counters ───────────────────────────
  app.get('/api/guild/:id/membercounters', requireAuth, guildGuard, (req, res) => {
    const guild = client.guilds.cache.get(req.params.id);
    res.json({
      counters: client.memberCounters.list(req.params.id),
      meta: { types: MC_COUNTER_TYPES },
      // Live values so the dashboard can preview the current count per type.
      preview: guild ? mcPreview(guild) : null
    });
  });

  app.post('/api/guild/:id/membercounters', requireAuth, guildGuard, (req, res) => {
    const blk = limitBlock(req.params.id, 'memberCounters', client.memberCounters.list(req.params.id).length + 1);
    if (blk) return res.status(blk.status).json(blk.body);
    const counter = client.memberCounters.create(req.params.id, req.body || {});
    if (!counter) return res.status(400).json({ error: 'Invalid counter — pick a channel and (for role counters) a role.' });
    mcService.updateGuild(client, req.params.id, { force: true }).catch(() => {});
    res.json({ success: true, counter });
  });

  app.put('/api/guild/:id/membercounters/order', requireAuth, guildGuard, (req, res) => {
    const order = Array.isArray(req.body?.order) ? req.body.order.filter(x => typeof x === 'string') : [];
    res.json({ success: true, counters: client.memberCounters.reorder(req.params.id, order) });
  });

  app.put('/api/guild/:id/membercounters/:counterId', requireAuth, guildGuard, (req, res) => {
    const counter = client.memberCounters.update(req.params.id, req.params.counterId, req.body || {});
    if (!counter) return res.status(404).json({ error: 'Counter not found or invalid.' });
    mcService.updateGuild(client, req.params.id, { force: true }).catch(() => {});
    res.json({ success: true, counter });
  });

  app.delete('/api/guild/:id/membercounters/:counterId', requireAuth, guildGuard, async (req, res) => {
    // Look the counter up first so we know which channel it was displaying in.
    const counter = client.memberCounters.get(req.params.id, req.params.counterId);
    if (!counter) return res.status(404).json({ error: 'Counter not found' });
    client.memberCounters.delete(req.params.id, req.params.counterId);

    // Also delete the Discord channel/category the counter was using.
    let channelDeleted = false;
    const guild = client.guilds.cache.get(req.params.id);
    const channel = guild?.channels.cache.get(counter.channelId);
    if (channel) {
      await channel.delete('Member counter removed from dashboard')
        .then(() => { channelDeleted = true; })
        .catch(e => logger.error(`Counter channel delete failed (${counter.channelId}): ${e.message}`));
    }
    res.json({ success: true, channelDeleted });
  });

  // Force an immediate refresh of all counter channels (bypasses the cooldown).
  app.post('/api/guild/:id/membercounters/refresh', requireAuth, guildGuard, async (req, res) => {
    await mcService.updateGuild(client, req.params.id, { force: true }).catch(() => {});
    res.json({ success: true });
  });

  const server = http.createServer(app);
  attachChat(server, sessionMiddleware, client);
  server.listen(PORT, () => {
    console.log(`📊 Dashboard → http://localhost:${PORT}`);
  });
};
